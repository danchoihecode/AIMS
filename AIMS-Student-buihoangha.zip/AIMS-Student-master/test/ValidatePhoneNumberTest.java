//import static org.junit.jupiter.api.Assertions.fail;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//class ValidatePhoneNumberTest {
//
//	@BeforeEach
//	void setUp() throws Exception {
//	}
//
//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}
//
//}
