package entity.seller_media;

public class SellerMediaItem {

}
